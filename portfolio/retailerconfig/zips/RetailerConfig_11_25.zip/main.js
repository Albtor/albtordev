function generateJSON() {
    var textArea = document.getElementById("textarea");
    textArea.innerHTML = "{JSON}\nNueva linea";
}


function generateJSONFormatted() {
    var textArea = document.getElementById("textarea");
    textArea.innerHTML = "{JSON Formatted}";
}

function copyJSON() {
    document.querySelector("textarea").select();
    document.execCommand('copy');
    alert("Copiado");
}

var a;
function showHideTS() {
    if(a !=1 ){
        document.getElementById("Timeslots").style.visibility = "visible";
        document.getElementById("ServiceTypes").style.visibility = "hidden";
        a=1;
        b=0;
        
    }else {
        document.getElementById("Timeslots").style.visibility = "hidden";
        a=0;
}
}

var b;
function showHideST() {
    if(b !=1 ){
        document.getElementById("ServiceTypes").style.visibility = "visible";
        document.getElementById("Timeslots").style.visibility = "hidden";
        b=1;
        a = 0;
    }else {
        document.getElementById("ServiceTypes").style.visibility = "hidden";
        b=0;
}
}


