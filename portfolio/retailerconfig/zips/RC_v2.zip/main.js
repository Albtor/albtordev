//CONFIGURATION TO GENERATE A JSON FROM THE VALUES SELECTED IN THE HTML 

var cutoff, 
is_wh, 
sms_disable_all, 
sms_pickup, 
sms_delivered, 
sms_delivery_attempt, 
sms_delivered_3rd_party, 
sms_delivery_information, 
mail_absent,
mail_pickup,
mail_rejected,
mail_delivered,
mail_incorrect_address,
mail_return_in_progress,
mail_delivered_3rd_party,
mail_delivery_information_type,
mail_delivery_information_timeslots,
saturday, 
sunday, 
parametric_config, 
is_warehouse_company, 
notification_service, 
show_distance_in_delivery_address, 
custom_timeslots,
show_service_types,
can_create_order_with_cod;

var TimeSlots = [], ServiceTypes = [];
var textArea = document.getElementById("textarea");

function getValues(type) {
    // textArea.style.backgroundColor = "black";
    textArea.style.cssText = "color: black";
    var jsonData = getJSON();
    
    //GENERAL
    cutoff = document.getElementById("cutoff").value;
    is_wh = document.getElementById("WH").value;
    notification_service = document.getElementById("NotificationService").value;
    jsonData.cutoff_time = cutoff;
    jsonData.is_warehouse_company = is_wh;
    jsonData.notification_service = notification_service;

    //SMS
    sms_disable_all = document.getElementById("sms_disable_all").value;  
    sms_pickup = document.getElementById("sms_pickup").value;  
    sms_delivered = document.getElementById("sms_delivered").value;  
    sms_delivery_attempt = document.getElementById("sms_delivery_attempt").value;  
    sms_delivered_3rd_party = document.getElementById("sms_delivered_3rd_party").value; 
    sms_delivery_information = document.getElementById("sms_delivery_information").value; 

    jsonData.notifications.sms.disable_all = sms_disable_all;
    jsonData.notifications.sms.pickup = sms_pickup;
    jsonData.notifications.sms.delivered = sms_delivered;
    jsonData.notifications.sms.delivered_3rd_party = sms_delivered_3rd_party;
    jsonData.notifications.sms.delivery_attempt = sms_delivery_attempt;
    jsonData.notifications.sms.delivery_information = sms_delivery_information;

    //EMAIL
    mail_delivery_information_type = document.getElementById("delivery_information_type").value;
    mail_absent = document.getElementById("email_absent").value;
    mail_pickup = document.getElementById("email_pickup").value;
    mail_rejected = document.getElementById("email_rejected").value;
    mail_delivered = document.getElementById("email_delivered").value;
    mail_incorrect_address = document.getElementById("email_incorrect_address").value;
    mail_return_in_progress = document.getElementById("email_return_in_progress").value;
    mail_delivered_3rd_party = document.getElementById("email_delivered_3rd_party").value;

    jsonData.notifications.email.absent = mail_absent;
    jsonData.notifications.email.pickup = mail_pickup;
    jsonData.notifications.email.rejected = mail_rejected;
    jsonData.notifications.email.delivered = mail_delivered;
    jsonData.notifications.email.incorrect_address = mail_incorrect_address;
    jsonData.notifications.email.return_in_progress = mail_return_in_progress;
    jsonData.notifications.email.delivered_3rd_party = mail_delivered_3rd_party;
    jsonData.notifications.email.delivery_information.type = mail_delivery_information_type;

    //WEEKENDS
    saturday = document.getElementById("saturday").value;
    sunday = document.getElementById("sunday").value;
    jsonData.weekend.saturday = saturday;
    jsonData.weekend.sunday = sunday;

    //MANUAL ORDERS 
    parametric_config = document.getElementById("parametric_config").value;
    show_distance_in_delivery_address = document.getElementById("show_distance_in_delivery_address").value;
    can_create_order_with_cod = document.getElementById("cod").value;
    custom_timeslots = document.getElementById("custom_timeslots").value;
    show_service_types = document.getElementById("show_service_types").value;

    jsonData.parametric_config = parametric_config;
    jsonData.show_distance_in_delivery_address = show_distance_in_delivery_address;
    jsonData.can_create_order_with_cod = can_create_order_with_cod;
    jsonData.time_slot_config.custom = custom_timeslots;
    jsonData.service_type_config.show = show_service_types;

    //SERVICE TYPES
    ServiceTypes = checkServiceTypesChecked();
    console.log("Service Types: " + ServiceTypes);
    jsonData.service_type_config.types = ServiceTypes;
    
    //TIMESLOTS
    TimeSlots = checkTimeSlotsChecked();

    jsonData.time_slot_config.slots = TimeSlots;
    jsonData.notifications.email.delivery_information.timeslots = TimeSlots;

    if (type == 1){
        generateJson(jsonData);
    }else {
        generateJsonFormatted(jsonData);
    }
}

function generateJson(jsonData){
    // var verify = checkFields();
    // if (!verify){
    //     alert("Choose ST and Timeslots")
    //     break;}
    var obj = JSON.stringify(jsonData);
    var textArea = document.getElementById("textarea");
    textArea.innerHTML = "";
    textArea.innerHTML = obj;
}


//FUNCTION TO GENERATE THE JSON NICE
function generateJsonFormatted(jsonData) {
    var obj = JSON.stringify(jsonData, null, 2);
    var textArea = document.getElementById("textarea");
    textArea.innerHTML = "";
    textArea.innerHTML = obj;
}


//FUNCTION TO CHECK THE SERVICE TYPES CHECKED
function checkServiceTypesChecked(){
    // var checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
    var ServiceTypesJson = [];
    var serviceTypes = document.getElementsByClassName('ServiceTypes'); // Selects all checkboxes with the class ServiceTypes
    for (var checkbox of serviceTypes){
        if (checkbox.checked) { //Checks if they are checked and saves the value in the array
            ServiceTypesJson.push(checkbox.value);
        }
    }
    return ServiceTypesJson;
}


//FUNCTION TO CHECK THE TIMESLOTS CHECKED
function checkTimeSlotsChecked(){
    // var checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
    var TimeslotsJson = [];
    var TimeslotsPage = document.getElementsByClassName('Timeslots'); 
    for (var checkbox2 of TimeslotsPage){
        if (checkbox2.checked) { 
            var Start = checkbox2.value.substring(0,5); //First Timeslot
            var End = checkbox2.value.substring(6,12); //Second Timeslot
            var object = {
                end: End,
                start: Start
            };
            // console.log("Start: "+ Start + " End: "+ End);
            TimeslotsJson.push(object);
        }
    }
    return TimeslotsJson;
}


//FUNCTION TO CHECK IF THERE ARE SERVICE TYPES AND TIMESLOTS SELECTED
//NOT NEEDED AS TIMESLOTS AND SERVICE TYPES ARE OPTIONAL
// function checkFields(){
//     var verify = false;
//     return verify;
// }


//TEMPLATE FOR THE JSON FOR CONFIGURATION
function getJSON(){
    var jsonData = {
        "cutoff_time":"00:00", //DONE
        "notifications":{
           "sms":{ //DONE
              "pickup":false,
              "delivered":true,
              "disable_all":false,
              "delivery_attempt":false,
              "delivered_3rd_party":true,
              "delivery_information":true
           },
           "email":{
              "absent":true,
              "pickup":false,
              "rejected":true,
              "delivered":true,
              "incorrect_address":true,
              "return_in_progress":true,
              "delivered_3rd_party":true,
              "delivery_information":{
                 "type":"dts_on_scan",
                 "timeslots":[
                 ]
              }
           }
        },
        "weekend":{ //DONE
           "sunday":true,
           "saturday":true
        },
        "time_slot_config":{
           "slots":[
              {
                 "end":"14:00",
                 "start":"10:00"
              },
              {
                 "end":"18:00",
                 "start":"14:00"
              },
              {
                 "end":"22:00",
                 "start":"18:00"
              }
           ],
           "custom":true
        },
        "parametric_config":true,
        "service_type_config":{
           "show":true,
           "types":[
              "NT4",
              "SF4"
           ]
        },
        "is_warehouse_company": true,
        "notification_service": true,
        "show_distance_in_delivery_address": true,
        "can_create_order_with_cod": true
     };
    return jsonData;
}


function clearTextArea(){
    var textArea = document.getElementById("textarea");
    textArea.style.cssText = "color: #EC9929";
}

function copyJSON() {
    document.querySelector("textarea").select();
    document.execCommand('copy');
    // alert("Copiado");
}


//TO HIDE AND SHOW THE SERVICE TYPES AND THE TIMESLOTS
var a;
function showHideTS() {
    if(a !=1 ){
        document.getElementById("Timeslots").style.visibility = "visible";
        document.getElementById("ServiceTypes").style.visibility = "hidden";
        a=1;
        b=0;
        
    }else {
        document.getElementById("Timeslots").style.visibility = "hidden";
        a=0;
}
}

var b;
function showHideST() {
    if(b !=1 ){
        document.getElementById("ServiceTypes").style.visibility = "visible";
        document.getElementById("Timeslots").style.visibility = "hidden";
        b=1;
        a = 0;
    }else {
        document.getElementById("ServiceTypes").style.visibility = "hidden";
        b=0;
}
}


